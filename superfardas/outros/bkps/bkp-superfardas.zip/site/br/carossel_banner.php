		<?php include_once "carossel_banner.php";?>
        <!-- carossel -->
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
          <!-- Indicadores -->
          <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
          </ol>
    
          <!-- Wrapper for slides -->
          <div class="carousel-inner" role="listbox" style="border-radius: 10px;">
            <div class="item active">
              <a href="http://www.superfardas.com.br/loja/" target="_blank"><img src="../images/banner_loja_viasol_site.png" alt="..."></a>
            </div>
            <div class="item">
              <a href="http://www.superfardas.com.br/loja/" target="_blank"><img src="../images/banner_loja_superfardas_site.png" alt="..."></a>
            </div>           
          </div><!-- carousel-inner -->
          
          <!-- Controls -->
         <!-- <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Voltar</span>
          </a>
          <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Seguir</span>
          </a>
        </div>-->
        <!-- /.carossel -->