 <!--<div class="row" style="background-color: #313667;">-->
 <div class="row" style="background-color: #333fb7">
   <div class="container">
		<div class="col-sm-12">
			<div class="col-sm-10">
				<ul class="nav nav-pills nav-justified">				
					<li role="presentation">
						<h6 style="color: #fff;"><strong>Atendimento ao cliente: (81) 3423.2377</strong></h6>
					</li>
				</ul>	
			</div>
			<div class="col-sm-2 col-md-2">
				<div class="social-top">
					<ul class="top-social">
						<li><a href="https://www.facebook.com/superfardas/" target="_blank"><img class="img-responsive" src="../images/icone/icone-facebook.png" width="20" height="20" alt="Facebook"/></a></li>
						<!--<li><a href="#" target="_blank"><img class="img-responsive" src="../images/icone/icone-twitter.png" width="20" height="20" alt="Twitter"/></a></li>-->
						<li><a href="https://www.instagram.com/superfardas/?hl=pt-br" target="_blank"><img class="img-responsive" src="../images/icone/icone-instagran.png" width="20" height="20" alt="Instagran"/></a></li>
					</ul>
				</div>
		  </div>
		</div>
	</div>
   <!-- /.container -->          
</div>