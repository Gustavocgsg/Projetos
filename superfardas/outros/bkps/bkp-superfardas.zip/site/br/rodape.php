        <!--Footer--> 
        <footer>
			<div class="conteiner">
				<div class="row">
					<div class="col-sm-4 col-md-4">
					<p></p>								
					</div>
					<div class="col-sm-4 col-md-4">
						<div class="social-top">
							<ul class="top-social">
								<li><a href="https://www.facebook.com/superfardas/" target="_blank"><img class="img-responsive img-center" src="../images/icone/icone-facebook.png" alt="Facebook"/></a></li>
								<!--<li><a href="#" target="_blank"><img class="img-responsive img-center" src="../images/icone/icone-twitter.png" alt="Twitter"/></a></li>-->
								<li><a href="https://www.instagram.com/superfardas/?hl=pt-br" target="_blank"><img class="img-responsive img-center" src="../images/icone/icone-instagran.png" alt="Instagran"/></a></li>
							</ul>
							<h4>Endereço</h4>
							<p>Rua Marques Amorim, 314 <br> Boa Vista, Recife - PE <br> CEP: 50.070-395</p>
						</div>
					</div>
					<div class="col-sm-4 col-md-4">
					<p></p>
					</div>														
				</div>
			</div>
            <!--/.row -->
            <div class="row">
            	<p>Prduzido por:</p>
            	<p><a href="http://superfardas.com.br/agenciaguimaraes/atendimento.php">agenciaguimaraes.com.br</a></p>
			</div>
            <!--/.row -->                              
        </footer>
        <!--/.Footer -->
        
        <!-- jQuery -->
        <script src="../js/jquery.js"></script>
        
        <!-- jQuery plugin -->
        <!--<script src="../js/jquery-1.12.0.min.js"></script>-->
        
        <!-- jQuery pluin ui -->
        <script src="../js/jquery-ui-1.11.4.js"></script>
    
        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>        