<!DOCTYPE HTML>
 <html lang="pt-br">
	<head>
	    <meta charset="utf-8"/>
	    <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
	    <meta http-equiv="refresh" content=1;url="http://www.superfardas.com.br/site/br/">
	    <!--<meta http-equiv="refresh" content=1;url="http://localhost/superfardas/br/">-->
	</head>
	<body>
		
	</body>
</html>