		<?php include_once "../en/carossel.php";?>
        <!-- pages Content -->
        <div class="container">
            <br>
            <div class="row">
                <div class="col-sm-4">
                    <img class="img-circle img-responsive img-center" src="../images/img-empresa.png" alt="">
                    <h2 class="text-center">Company</h2>
                    <p class="text-center">What a Text ?</p>
                    <p class="text-center">
                        <a class="btn btn-default" href="?pages=company">see details</a>
                    </p>
                </div>
                <div class="col-sm-4">
                    <img class="img-circle img-responsive img-center" src="../images/img_produto.png" alt="">
                    <h2 class="text-center">Product</h2>
                    <p class="text-center">What a Text ?</p>
                    <p class="text-center">
                        <a class="btn btn-default" href="?pages=product">see details</a>
                    </p>
                </div>
                <div class="col-sm-4">
                    <img class="img-circle img-responsive img-center" src="../images/img-orcamento.png" alt="">
                    <h2 class="text-center">Budget</h2>
                    <p class="text-center">What a Text ?</p>
                    <p class="text-center">
                        <a class="btn btn-default" href="?pages=budget">see details</a>
                    </p>
                </div>
            </div>
            <!-- /.row -->
    
            <hr>
    
            <div class="row">
                <div class="col-sm-8">
                    <h2>Ecology</h2>
                    <p>Aware of the great problem of illegal logging and destruction of forests, IDEMAL produces its packaging and pallets with reforested wood.</p>
                </div>
                <div class="col-sm-4">
                    <img class="img-circle img-responsive img-center" src="../images/img_ecologia.png" alt="">
                </div>       
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->