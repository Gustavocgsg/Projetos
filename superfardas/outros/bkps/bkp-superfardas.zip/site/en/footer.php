        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-sm-12">
                    <div class="col-sm-6">
                    <strong>Social networks</strong><br />
                        <ul class="list-inline">
                            <li><a href=""><img src="../images/img_face_icon.png" alt="Ir para página do facebook"></a></li>
                            <li><a href=""><img src="../images/img_youtube_icon.png" alt="Ir ao canal do Youtube"></a></li>
                            <li><a href=""><img src="../images/img_maps_icon.png" alt="Saber localização no Google Maps"></a></li>
                            <li><a href=""><img src="../images/img_twitter_icon.png" alt="Ir a para a página do Twitter"></a></li>
                        </ul>   
                    </div>
                    <div class="col-sm-6">
                        <strong>Time Service</strong>
                        <p>From Monday to Friday<br />	
                        08:00 às 17:00 </p>
                        
                        <strong>Address</strong><br />
                        <p>Street Carmela Dutra, 623 - People's Village - PE</p>                
                    </div>
                </div>
            </div>
            <!-- /.row -->
            <div class="col-sm-12 rodape"></div>
        </footer>
        <!-- /.Footer -->
        
        <!-- jQuery -->
        <script src="../js/jquery.js"></script>
    
        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>        